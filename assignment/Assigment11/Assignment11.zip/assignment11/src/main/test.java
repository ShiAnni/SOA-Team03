package main;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import cn.edu.nju.jw.wsdl.IdNotFoundFault;
import cn.edu.nju.jw.wsdl.IdNotValidFault;
import cn.edu.nju.jw.wsdl.OtherFault;
import cn.edu.nju.jw.wsdl.ScoreServiceStub;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.ScoreList;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.StudentId;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.课程成绩列表类型;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.课程成绩列表类型Sequence;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.课程成绩类型;
import cn.edu.nju.jw.wsdl.ScoreServiceStub.课程成绩类型Sequence;

public class test {
public static void main(String args[]) throws AxisFault{
	
	String stuId = "141250009";
	ScoreServiceStub stub = new ScoreServiceStub("http://localhost:8080/SchoolService/services/ScoreService");
	System.out.println("------------ScoreService-----------");
	System.out.println("------------getScore-------------");
	System.out.println("studentId: " + stuId);
	StudentId studentId = new StudentId();
	ScoreServiceStub.学号类型 st = new ScoreServiceStub.学号类型();
	studentId.setStudentId(st);
	st.set学号类型(stuId);


	try {
		ScoreList scoreList = stub.getscore(studentId);

		课程成绩列表类型 cslt = scoreList.getScoreList();

		for(课程成绩列表类型Sequence cslts : cslt.get课程成绩列表类型Sequence()){
			课程成绩类型 cst = cslts.get课程成绩();
			System.out.print("课程编号: " + cst.get课程编号().get课程编号类型() + "  ");
			System.out.println("成绩性质: " + cst.get成绩性质().getValue());

			for(课程成绩类型Sequence csts : cst.get课程成绩类型Sequence()){
				System.out.println("学号: " + csts.get成绩().get学号().get学号类型() + "  成绩: " + csts.get成绩().get得分().get得分类型());
			}

		}

	} catch (RemoteException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();

	} catch (IdNotFoundFault e) {
		// TODO Auto-generated catch block
		e.printStackTrace();

	} catch (IdNotValidFault e) {
		// TODO Auto-generated catch block
		e.printStackTrace();

	} catch (OtherFault e) {
		// TODO Auto-generated catch block
		e.printStackTrace();

	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();

	}

	System.out.println();
	
}
}
