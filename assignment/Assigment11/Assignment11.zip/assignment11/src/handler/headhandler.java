package handler;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;



public class headhandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		System.out.println("handler running");
		String trueemail ="141250009";
		String truepassword ="yx13776708583CF";
		//获取soap里的header
		SOAPMessage message =context.getMessage();
		SOAPEnvelope envelope =null;
		SOAPHeader header=null;
		try {
			envelope = message.getSOAPPart().getEnvelope();
			 header =envelope.getHeader();
			 
			if(header ==null){
				header = envelope.addHeader();				
			}
			QName email =new QName("http://jw.nju.edu.cn/", "email","tns");
			QName password =new QName("http://jw.nju.edu.cn/", "password","tns");
			header.addChildElement(email).setValue(trueemail);;
			header.addChildElement(password).setValue(truepassword);
			System.out.println("header is already in");
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//添加验证信息
	
		return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
