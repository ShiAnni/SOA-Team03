package handler;

import java.rmi.RemoteException;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.axis2.AxisFault;
import org.w3c.dom.Node;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

import cn.edu.nju.service.LoginMailServiceImplStub;
import cn.edu.nju.service.LoginMailServiceImplStub.Login;
import cn.edu.nju.service.LoginMailServiceImplStub.LoginResponse;





public class loginhandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		boolean result =false;
		//获取验证消息
		LoginMailServiceImplStub stub = null;
		try {
		 stub = new LoginMailServiceImplStub("http://localhost:8080/LoginService/services/LoginMailServiceImpl");
		} catch (AxisFault e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		SOAPMessage message =context.getMessage();
		SOAPEnvelope envelope =null;
		SOAPHeader header=null;
		SOAPBody body =null;
		Node node =null;
		Node bd =null;
		String email =null;
		String password =null;
		String responcereturn =null;
		String rqname =null;
		try {
			envelope = message.getSOAPPart().getEnvelope();
			 header =envelope.getHeader();
			 body =envelope.getBody();
			 
			node = header.getElementsByTagName("tns:email").item(0);
			email =node.getTextContent();
			
			node = header.getElementsByTagName("tns:password").item(0);
			password =node.getTextContent();
			
			bd =body.getFirstChild();
			 rqname = bd.getLocalName();
			System.out.println("rqname is"+rqname);
		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Login request = new Login();
		request.setEmail(email);
		request.setPassword(password);
		try {
			LoginResponse response = stub.login(request);
			System.out.print("验证邮箱: "+email+"验证结果: ");
			responcereturn =response.get_return();
			System.out.println(response.get_return());
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//返回验证结果
		if(responcereturn.equals("邮箱格式错误!\n登录失败，无法验证邮箱!")){
			result =false;
		}else if(responcereturn.equals("账号或者密码错误!\n登录失败，无法验证邮箱!")) {
			result =false;
		}else if(responcereturn.equals("登录成功!\n邮箱身份为研究生")){
			if(rqname.equals("getInfoById")||rqname.equals("getInfoByName")){
				result =true;
			}else{result=false;}
		}else if(responcereturn.equals("登录成功!\n邮箱身份为本科生")){
			if(rqname.equals("getInfoById")||rqname.equals("getInfoByName")){
				result =true;
			}else{result=false;}
		}else if(responcereturn.equals("登录成功!\n邮箱身份为教师")){
			result =true;
		}
		return result;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
