
/**
 * IdNotValidFault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */

package cn.edu.nju.jw.wsdl;

public class IdNotValidFault extends java.lang.Exception{

    private static final long serialVersionUID = 1497376619158L;
    
    private cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault faultMessage;

    
        public IdNotValidFault() {
            super("IdNotValidFault");
        }

        public IdNotValidFault(java.lang.String s) {
           super(s);
        }

        public IdNotValidFault(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public IdNotValidFault(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault msg){
       faultMessage = msg;
    }
    
    public cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault getFaultMessage(){
       return faultMessage;
    }
}
    