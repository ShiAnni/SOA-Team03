
/**
 * OtherFault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */

package cn.edu.nju.jw.wsdl;

public class OtherFault extends java.lang.Exception{

    private static final long serialVersionUID = 1497376619169L;
    
    private cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault faultMessage;

    
        public OtherFault() {
            super("OtherFault");
        }

        public OtherFault(java.lang.String s) {
           super(s);
        }

        public OtherFault(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public OtherFault(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault msg){
       faultMessage = msg;
    }
    
    public cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault getFaultMessage(){
       return faultMessage;
    }
}
    