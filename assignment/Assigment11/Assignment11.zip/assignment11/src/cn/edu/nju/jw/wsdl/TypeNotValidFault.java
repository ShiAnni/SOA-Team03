
/**
 * TypeNotValidFault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */

package cn.edu.nju.jw.wsdl;

public class TypeNotValidFault extends java.lang.Exception{

    private static final long serialVersionUID = 1497374160254L;
    
    private cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.InvalidDataFault faultMessage;

    
        public TypeNotValidFault() {
            super("TypeNotValidFault");
        }

        public TypeNotValidFault(java.lang.String s) {
           super(s);
        }

        public TypeNotValidFault(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public TypeNotValidFault(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.InvalidDataFault msg){
       faultMessage = msg;
    }
    
    public cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.InvalidDataFault getFaultMessage(){
       return faultMessage;
    }
}
    