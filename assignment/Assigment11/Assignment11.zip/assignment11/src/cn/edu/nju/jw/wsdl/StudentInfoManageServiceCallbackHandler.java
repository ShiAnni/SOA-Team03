
/**
 * StudentInfoManageServiceCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */

    package cn.edu.nju.jw.wsdl;

    /**
     *  StudentInfoManageServiceCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class StudentInfoManageServiceCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public StudentInfoManageServiceCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public StudentInfoManageServiceCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for getInfoById method
            * override this method for handling normal response from getInfoById operation
            */
           public void receiveResultgetInfoById(
                    cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.StudentMsg result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from getInfoById operation
           */
            public void receiveErrorgetInfoById(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for addInfo method
            * override this method for handling normal response from addInfo operation
            */
           public void receiveResultaddInfo(
                    cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.AddResult result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from addInfo operation
           */
            public void receiveErroraddInfo(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for getInfoByName method
            * override this method for handling normal response from getInfoByName operation
            */
           public void receiveResultgetInfoByName(
                    cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.StudentList result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from getInfoByName operation
           */
            public void receiveErrorgetInfoByName(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for modifyInfo method
            * override this method for handling normal response from modifyInfo operation
            */
           public void receiveResultmodifyInfo(
                    cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.SuccessInfoDM result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from modifyInfo operation
           */
            public void receiveErrormodifyInfo(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for delInfo method
            * override this method for handling normal response from delInfo operation
            */
           public void receiveResultdelInfo(
                    cn.edu.nju.jw.wsdl.StudentInfoManageServiceStub.SuccessInfoDM result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from delInfo operation
           */
            public void receiveErrordelInfo(java.lang.Exception e) {
            }
                


    }
    