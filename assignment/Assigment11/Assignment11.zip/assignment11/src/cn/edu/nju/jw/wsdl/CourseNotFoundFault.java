
/**
 * CourseNotFoundFault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */

package cn.edu.nju.jw.wsdl;

public class CourseNotFoundFault extends java.lang.Exception{

    private static final long serialVersionUID = 1497376619192L;
    
    private cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault faultMessage;

    
        public CourseNotFoundFault() {
            super("CourseNotFoundFault");
        }

        public CourseNotFoundFault(java.lang.String s) {
           super(s);
        }

        public CourseNotFoundFault(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public CourseNotFoundFault(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault msg){
       faultMessage = msg;
    }
    
    public cn.edu.nju.jw.wsdl.ScoreServiceStub.InvalidDataFault getFaultMessage(){
       return faultMessage;
    }
}
    