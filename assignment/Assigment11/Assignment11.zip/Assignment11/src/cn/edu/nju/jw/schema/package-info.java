@javax.xml.bind.annotation.XmlSchema(namespace = "http://jw.nju.edu.cn/schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cn.edu.nju.jw.schema;
