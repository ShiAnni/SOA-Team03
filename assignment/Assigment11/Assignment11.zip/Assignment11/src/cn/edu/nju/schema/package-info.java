@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.nju.edu.cn/schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cn.edu.nju.schema;
