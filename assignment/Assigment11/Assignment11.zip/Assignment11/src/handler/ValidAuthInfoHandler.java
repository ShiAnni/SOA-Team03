package handler;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.w3c.dom.Node;

import cn.edu.nju.jw.schema.AuthControllerService;
import cn.edu.nju.jw.schema.AuthFaultType;
import cn.edu.nju.jw.schema.AuthorityException;
import cn.edu.nju.jw.schema.IdNotFoundException;
import cn.edu.nju.jw.schema.MyAuth;
import cn.edu.nju.jw.schema.PswErrorException;
import cn.edu.nju.jw.schema.账号认证类型;
import cn.edu.nju.jw.schema.验证类型;


public class ValidAuthInfoHandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public boolean handleMessage(SOAPMessageContext context) {

		Boolean out = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		try {
			if (out) {
				SOAPMessage message = context.getMessage();

	//			System.out.println("------ValidAuthInfoHandler In------");
	//			message.writeTo(System.out);
	//			System.out.println();

				SOAPHeader header = message.getSOAPPart().getEnvelope().getHeader();
				SOAPBody body = message.getSOAPPart().getEnvelope().getBody();

				Node node = header.getElementsByTagName("tns:email").item(0);
				String email = node.getTextContent();
				node = header.getElementsByTagName("tns:password").item(0);
				String password = node.getTextContent();
				node = header.getElementsByTagName("tns:action").item(0);
				String action = node.getTextContent();

//				System.out.println("email is " + email);
//				System.out.println("password is " +password);

				//TODO 初始化Login服务并进行身份验证 
				AuthControllerService authControllerService = new AuthControllerService();
				MyAuth myAuth = authControllerService.getMyAuthPort();
				账号认证类型 account = new 账号认证类型();
				account.set邮箱(email);
				account.set密码(password);
				验证类型 type = null; 
				String result = "未知类型";
				try {
					type = myAuth.verify(account);
					result = type.get权限().toString();
				} catch (IdNotFoundException e) {
					System.out.println("邮箱不存在！");
				} catch (PswErrorException e) {
					System.out.println("密码错误！");
				}
				

				QName qName = new QName("http://jw.nju.edu.cn/","identity", "tns");

				if(result.equals("老师")){
					header.addChildElement(qName).setValue("teacher");
				}else if(result.equals("本科生") || result.equals("研究生")){
					header.addChildElement(qName).setValue("student");
					// 学生不能调用getScore以外的方法
					if (!"query".equals(action)) {
						throw new AuthorityException("权限不够，无法调用", new AuthFaultType());
						
					}
				}else{
					System.out.println("身份验证失败！");
					return false;
				}
	//			System.out.println("-----ValidAuthInfoHandler Out-----");
				message.writeTo(System.out);
	//			System.out.println();
			}

		} catch (SOAPException | RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (AuthorityException e) {
			System.out.println("权限不够，无法调用");
		}
		return true;	
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
