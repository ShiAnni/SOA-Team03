﻿0.文件说明：
（1）项目源代码在Assigment11里(项目使用utf -8编码)。
（2）项目运行的控制台输出结果（以老师调用——学生调用——错误调用顺序）已经保存在了“控制台输出.txt”中。

1、项目结构说明：

（1）cn.edu.nju.jw.schema下使用wsimport为三个服务生成的客户端代码。

（2）handler包下是两个Handler，其中AddAuthInfoHandler在Header中添加邮箱和密码；
ValidAuthInfoHandler对邮箱进行验证。


（3）service包下的类是先为服务添加handler，然后调用服务接口 运行service中的main方法即可。

2、其中三个服务都是调用的18组的
。

